import React, { Component } from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';


export default class App extends Component {
   constructor(){
     super()
     this.state = {
firststate:0
     }
     
   }
componentDidMount(){

  console.log("thisisthecomponentdidmountfunction")
}

  render() {
    return (
      <View style={{ flex: 1 }}>yes
        <Text style={{ marginTop: 50, marginLeft: 170 }}>
          Component Lifecycle
        </Text>
      </View>
    );
  }
}
